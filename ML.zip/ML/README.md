# Renewable Energy Prediction Website

## Structure

```text
Renewable_Energy_Website/
├── backend/
│   ├── app.py
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── models/
│   ├── xgboost_model.joblib
│   └── lightgbm_model.joblib
└── data/
```

## 1. Copy your trained models

Copy these files from your existing ML project:

```text
models/xgboost_model.joblib
models/lightgbm_model.joblib
```

into this project's `models` folder.

## 2. Install backend packages

Open a terminal in the project folder:

```powershell
cd backend
python -m pip install -r requirements.txt
```

## 3. Start backend

```powershell
python app.py
```

The API runs at:

```text
http://127.0.0.1:5000
```

## 4. Start frontend

Open a second terminal:

```powershell
cd frontend
python -m http.server 5500
```

Open:

```text
http://127.0.0.1:5500
```

## API

POST `/predict`

Example JSON:

```json
{
  "ambient_temperature": 25,
  "module_temperature": 35,
  "irradiation": 0.5,
  "hour": 12,
  "minute": 0,
  "day": 15,
  "month": 5,
  "day_of_week": 2,
  "model": "both"
}
```

The backend returns XGBoost and/or LightGBM AC power predictions.
