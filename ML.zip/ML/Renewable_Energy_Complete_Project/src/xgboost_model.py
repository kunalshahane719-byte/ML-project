from xgboost import XGBRegressor


def build_xgboost_model() -> XGBRegressor:
    """Create XGBoost regression model."""
    return XGBRegressor(
        n_estimators=300,
        learning_rate=0.05,
        max_depth=6,
        min_child_weight=1,
        subsample=0.90,
        colsample_bytree=0.90,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1
    )
