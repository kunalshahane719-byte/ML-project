from pathlib import Path
import pandas as pd


def load_plant_data(raw_dir: Path, plant_number: int) -> pd.DataFrame | None:
    """
    Load and merge generation and weather data for one plant.

    Expected files:
        Plant_1_Generation_Data.csv
        Plant_1_Weather_Sensor_Data.csv
        Plant_2_Generation_Data.csv
        Plant_2_Weather_Sensor_Data.csv
    """
    generation_file = raw_dir / f"Plant_{plant_number}_Generation_Data.csv"
    weather_file = raw_dir / f"Plant_{plant_number}_Weather_Sensor_Data.csv"

    if not generation_file.exists() or not weather_file.exists():
        return None

    generation = pd.read_csv(generation_file)
    weather = pd.read_csv(weather_file)

    generation["DATE_TIME"] = pd.to_datetime(
        generation["DATE_TIME"], errors="coerce", dayfirst=True
    )
    weather["DATE_TIME"] = pd.to_datetime(
        weather["DATE_TIME"], errors="coerce", dayfirst=True
    )

    # SOURCE_KEY exists in both files but represents different things:
    # inverter ID in generation data and weather sensor ID in weather data.
    # Therefore we merge only on timestamp and plant id.
    merged = pd.merge(
        generation,
        weather,
        on=["DATE_TIME", "PLANT_ID"],
        how="inner",
        suffixes=("_GEN", "_WEATHER")
    )

    merged["PLANT_NUMBER"] = plant_number
    return merged


def load_all_data(raw_dir: str | Path) -> pd.DataFrame:
    """Load Plant 1 and Plant 2 if available."""
    raw_dir = Path(raw_dir)

    frames = []
    for plant_number in (1, 2):
        df = load_plant_data(raw_dir, plant_number)
        if df is not None:
            frames.append(df)

    if not frames:
        raise FileNotFoundError(
            "No Kaggle solar CSV files found in dataset/raw/. "
            "Please add at least Plant_1_Generation_Data.csv and "
            "Plant_1_Weather_Sensor_Data.csv."
        )

    data = pd.concat(frames, ignore_index=True)
    return data


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning."""
    cleaned = df.copy()

    cleaned = cleaned.dropna(subset=["DATE_TIME"])
    cleaned = cleaned.drop_duplicates()

    required_columns = [
        "AC_POWER",
        "AMBIENT_TEMPERATURE",
        "MODULE_TEMPERATURE",
        "IRRADIATION",
    ]

    missing = [col for col in required_columns if col not in cleaned.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    for col in required_columns:
        cleaned[col] = pd.to_numeric(cleaned[col], errors="coerce")

    cleaned = cleaned.dropna(subset=required_columns)

    # Solar AC power should not be negative.
    cleaned["AC_POWER"] = cleaned["AC_POWER"].clip(lower=0)

    cleaned = cleaned.sort_values("DATE_TIME").reset_index(drop=True)
    return cleaned


def save_processed_data(df: pd.DataFrame, output_path: str | Path) -> None:
    """Save processed dataset."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
