from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def calculate_metrics(y_true, y_pred) -> dict:
    """Calculate regression metrics."""
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "R2": r2_score(y_true, y_pred),
    }


def save_eda_plots(df: pd.DataFrame, results_dir: str | Path) -> None:
    """Generate basic exploratory data analysis plots."""
    results_dir = Path(results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)

    # Power over time.
    daily = (
        df.set_index("DATE_TIME")["AC_POWER"]
        .resample("D")
        .mean()
        .dropna()
    )

    plt.figure(figsize=(12, 5))
    plt.plot(daily.index, daily.values)
    plt.xlabel("Date")
    plt.ylabel("Average AC Power")
    plt.title("Solar Power Generation Over Time")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(results_dir / "01_power_over_time.png", dpi=200)
    plt.close()

    # Irradiation vs AC power.
    sample = df.sample(min(5000, len(df)), random_state=42)

    plt.figure(figsize=(8, 5))
    plt.scatter(sample["IRRADIATION"], sample["AC_POWER"], s=10, alpha=0.5)
    plt.xlabel("Irradiation")
    plt.ylabel("AC Power")
    plt.title("Irradiation vs AC Power")
    plt.tight_layout()
    plt.savefig(results_dir / "02_irradiation_vs_power.png", dpi=200)
    plt.close()

    # Ambient temperature vs AC power.
    plt.figure(figsize=(8, 5))
    plt.scatter(
        sample["AMBIENT_TEMPERATURE"],
        sample["AC_POWER"],
        s=10,
        alpha=0.5
    )
    plt.xlabel("Ambient Temperature")
    plt.ylabel("AC Power")
    plt.title("Ambient Temperature vs AC Power")
    plt.tight_layout()
    plt.savefig(results_dir / "03_temperature_vs_power.png", dpi=200)
    plt.close()

    # Correlation heatmap.
    corr_cols = [
        "AMBIENT_TEMPERATURE",
        "MODULE_TEMPERATURE",
        "IRRADIATION",
        "AC_POWER",
    ]
    corr = df[corr_cols].corr()

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(corr.values, aspect="auto")

    ax.set_xticks(range(len(corr_cols)))
    ax.set_yticks(range(len(corr_cols)))
    ax.set_xticklabels(corr_cols, rotation=45, ha="right")
    ax.set_yticklabels(corr_cols)

    fig.colorbar(im, ax=ax, label="Correlation")
    ax.set_title("Feature Correlation Heatmap")

    plt.tight_layout()
    plt.savefig(results_dir / "04_correlation_heatmap.png", dpi=200)
    plt.close()


def save_actual_vs_predicted_plot(
    dates,
    y_true,
    xgb_pred,
    lgb_pred,
    results_dir: str | Path,
) -> None:
    """Plot actual vs predicted values."""
    results_dir = Path(results_dir)

    n = min(500, len(y_true))

    plt.figure(figsize=(13, 5))
    plt.plot(dates.iloc[:n], y_true.iloc[:n].values, label="Actual")
    plt.plot(dates.iloc[:n], xgb_pred[:n], label="XGBoost")
    plt.plot(dates.iloc[:n], lgb_pred[:n], label="LightGBM")

    plt.xlabel("Date/Time")
    plt.ylabel("AC Power")
    plt.title("Actual vs Predicted Solar Power")
    plt.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()

    plt.savefig(results_dir / "05_actual_vs_predicted.png", dpi=200)
    plt.close()


def save_feature_importance(
    model,
    feature_names,
    results_dir: str | Path,
    file_name: str,
    title: str,
) -> None:
    """Save feature importance image and CSV."""
    results_dir = Path(results_dir)

    importance = pd.Series(
        model.feature_importances_,
        index=feature_names
    ).sort_values()

    plt.figure(figsize=(9, 6))
    plt.barh(importance.index, importance.values)
    plt.xlabel("Importance")
    plt.ylabel("Feature")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(results_dir / file_name, dpi=200)
    plt.close()

    csv_name = file_name.replace(".png", ".csv")
    importance.rename("Importance").to_csv(results_dir / csv_name)


def save_metric_comparison(metrics_df: pd.DataFrame, results_dir: str | Path) -> None:
    """Create one comparison image per metric."""
    results_dir = Path(results_dir)

    for metric in ["MAE", "RMSE", "R2", "Training_Time_Seconds"]:
        plt.figure(figsize=(7, 5))
        plt.bar(metrics_df["Model"], metrics_df[metric])
        plt.ylabel(metric)
        plt.title(f"{metric} Comparison")
        plt.tight_layout()
        plt.savefig(
            results_dir / f"comparison_{metric.lower()}.png",
            dpi=200
        )
        plt.close()
