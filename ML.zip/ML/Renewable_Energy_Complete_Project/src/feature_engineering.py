import numpy as np
import pandas as pd


FEATURE_COLUMNS = [
    "AMBIENT_TEMPERATURE",
    "MODULE_TEMPERATURE",
    "IRRADIATION",
    "HOUR",
    "MINUTE",
    "DAY",
    "MONTH",
    "DAY_OF_WEEK",
    "HOUR_SIN",
    "HOUR_COS",
]


def create_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create time-based features from DATE_TIME.

    Target:
        AC_POWER
    """
    data = df.copy()

    data["HOUR"] = data["DATE_TIME"].dt.hour
    data["MINUTE"] = data["DATE_TIME"].dt.minute
    data["DAY"] = data["DATE_TIME"].dt.day
    data["MONTH"] = data["DATE_TIME"].dt.month
    data["DAY_OF_WEEK"] = data["DATE_TIME"].dt.dayofweek

    # Cyclic representation of hour.
    data["HOUR_SIN"] = np.sin(2 * np.pi * data["HOUR"] / 24.0)
    data["HOUR_COS"] = np.cos(2 * np.pi * data["HOUR"] / 24.0)

    return data


def get_model_data(df: pd.DataFrame):
    """Return X, y and selected feature names."""
    available_features = [c for c in FEATURE_COLUMNS if c in df.columns]

    if not available_features:
        raise ValueError("No usable features found.")

    X = df[available_features].copy()
    y = df["AC_POWER"].copy()

    return X, y, available_features
