from lightgbm import LGBMRegressor


def build_lightgbm_model() -> LGBMRegressor:
    """Create LightGBM regression model."""
    return LGBMRegressor(
        n_estimators=300,
        learning_rate=0.05,
        num_leaves=31,
        max_depth=-1,
        subsample=0.90,
        colsample_bytree=0.90,
        objective="regression",
        random_state=42,
        n_jobs=-1,
        verbosity=-1
    )
