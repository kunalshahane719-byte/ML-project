const API_URL = "http://127.0.0.1:5000";

const form = document.getElementById("predictionForm");
const statusBox = document.getElementById("status");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const payload = {
    ambient_temperature: Number(document.getElementById("ambient_temperature").value),
    module_temperature: Number(document.getElementById("module_temperature").value),
    irradiation: Number(document.getElementById("irradiation").value),
    hour: Number(document.getElementById("hour").value),
    minute: Number(document.getElementById("minute").value),
    day: Number(document.getElementById("day").value),
    month: Number(document.getElementById("month").value),
    day_of_week: Number(document.getElementById("day_of_week").value),
    model: document.getElementById("model").value
  };

  statusBox.textContent = "Predicting...";

  try {
    const response = await fetch(`${API_URL}/predict`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Prediction failed");
    }

    document.getElementById("xgbResult").textContent =
      data.xgboost !== null && data.xgboost !== undefined
        ? `${Math.max(0, data.xgboost).toFixed(2)}`
        : "—";

    document.getElementById("lgbmResult").textContent =
      data.lightgbm !== null && data.lightgbm !== undefined
        ? `${Math.max(0, data.lightgbm).toFixed(2)}`
        : "—";

    statusBox.textContent = "Prediction completed successfully.";
  } catch (error) {
    statusBox.textContent = error.message;
  }
});
