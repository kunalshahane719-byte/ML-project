from flask import Flask, request, jsonify
from flask_cors import CORS
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

app = Flask(__name__)
CORS(app)

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE_DIR / "models"

XGB_PATH = MODEL_DIR / "xgboost_model.joblib"
LGBM_PATH = MODEL_DIR / "lightgbm_model.joblib"

xgb_model = joblib.load(XGB_PATH) if XGB_PATH.exists() else None
lgbm_model = joblib.load(LGBM_PATH) if LGBM_PATH.exists() else None


def make_features(data):
    hour = float(data["hour"])
    minute = float(data["minute"])
    hour_decimal = hour + minute / 60.0

    return pd.DataFrame([{
        "AMBIENT_TEMPERATURE": float(data["ambient_temperature"]),
        "MODULE_TEMPERATURE": float(data["module_temperature"]),
        "IRRADIATION": float(data["irradiation"]),
        "HOUR": int(hour),
        "MINUTE": int(minute),
        "DAY": int(data["day"]),
        "MONTH": int(data["month"]),
        "DAY_OF_WEEK": int(data["day_of_week"]),
        "HOUR_SIN": np.sin(2 * np.pi * hour_decimal / 24),
        "HOUR_COS": np.cos(2 * np.pi * hour_decimal / 24)
    }])


@app.get("/")
def home():
    return jsonify({
        "message": "Renewable Energy Prediction API is running",
        "endpoint": "/predict"
    })


@app.get("/health")
def health():
    return jsonify({
        "status": "ok",
        "xgboost_loaded": xgb_model is not None,
        "lightgbm_loaded": lgbm_model is not None
    })


@app.post("/predict")
def predict():
    try:
        data = request.get_json(force=True)
        features = make_features(data)
        selected = data.get("model", "both").lower()

        result = {"xgboost": None, "lightgbm": None}

        if selected in ("xgboost", "both"):
            if xgb_model is None:
                return jsonify({"error": "XGBoost model file not found"}), 500
            result["xgboost"] = float(xgb_model.predict(features)[0])

        if selected in ("lightgbm", "both"):
            if lgbm_model is None:
                return jsonify({"error": "LightGBM model file not found"}), 500
            result["lightgbm"] = float(lgbm_model.predict(features)[0])

        return jsonify(result)

    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
