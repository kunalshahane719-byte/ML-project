from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import streamlit as st


BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"


st.set_page_config(
    page_title="Renewable Energy Prediction",
    page_icon="☀️",
    layout="centered"
)

st.title("☀️ Renewable Energy Output Prediction")
st.write("Predict solar AC power using XGBoost or LightGBM.")


xgb_path = MODELS_DIR / "xgboost_model.pkl"
lgb_path = MODELS_DIR / "lightgbm_model.pkl"
features_path = MODELS_DIR / "feature_columns.pkl"

if not xgb_path.exists() or not lgb_path.exists() or not features_path.exists():
    st.error(
        "Trained model files are missing. "
        "Run `python main.py` before starting the Streamlit app."
    )
    st.stop()


xgb_model = joblib.load(xgb_path)
lgb_model = joblib.load(lgb_path)
feature_columns = joblib.load(features_path)


model_name = st.selectbox(
    "Select Model",
    ["XGBoost", "LightGBM"]
)

ambient_temperature = st.number_input(
    "Ambient Temperature (°C)",
    value=30.0
)

module_temperature = st.number_input(
    "Module Temperature (°C)",
    value=45.0
)

irradiation = st.number_input(
    "Irradiation",
    min_value=0.0,
    value=0.50
)

hour = st.slider(
    "Hour",
    min_value=0,
    max_value=23,
    value=12
)

minute = st.selectbox(
    "Minute",
    [0, 15, 30, 45],
    index=0
)

day = st.number_input(
    "Day",
    min_value=1,
    max_value=31,
    value=15
)

month = st.number_input(
    "Month",
    min_value=1,
    max_value=12,
    value=5
)

day_of_week = st.number_input(
    "Day of Week (0=Monday, 6=Sunday)",
    min_value=0,
    max_value=6,
    value=4
)


input_data = {
    "AMBIENT_TEMPERATURE": ambient_temperature,
    "MODULE_TEMPERATURE": module_temperature,
    "IRRADIATION": irradiation,
    "HOUR": hour,
    "MINUTE": minute,
    "DAY": day,
    "MONTH": month,
    "DAY_OF_WEEK": day_of_week,
    "HOUR_SIN": np.sin(2 * np.pi * hour / 24.0),
    "HOUR_COS": np.cos(2 * np.pi * hour / 24.0),
}

input_df = pd.DataFrame([input_data])

# Use only the exact features used during training.
input_df = input_df[feature_columns]


if st.button("Predict"):
    if model_name == "XGBoost":
        model = xgb_model
    else:
        model = lgb_model

    prediction = model.predict(input_df)[0]

    st.success(
        f"Predicted AC Power: {prediction:.2f}"
    )


st.divider()

st.subheader("Input Data")
st.dataframe(input_df)
