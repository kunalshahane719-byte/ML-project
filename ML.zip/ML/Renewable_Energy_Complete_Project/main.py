import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
import joblib


# ==============================
# 1. FOLDERS
# ==============================

RAW = "dataset/raw"
PROCESSED = "dataset/processed"
RESULTS = "results"
MODELS = "models"

os.makedirs(PROCESSED, exist_ok=True)
os.makedirs(RESULTS, exist_ok=True)
os.makedirs(MODELS, exist_ok=True)


# ==============================
# 2. LOAD DATASET
# ==============================

print("\nLoading dataset...")

generation = pd.read_csv(
    os.path.join(RAW, "Plant_1_Generation_Data.csv")
)

weather = pd.read_csv(
    os.path.join(RAW, "Plant_1_Weather_Sensor_Data.csv")
)

print("Generation data:", generation.shape)
print("Weather data:", weather.shape)


# ==============================
# 3. MERGE DATA
# ==============================

generation["DATE_TIME"] = pd.to_datetime(generation["DATE_TIME"])
weather["DATE_TIME"] = pd.to_datetime(weather["DATE_TIME"])

data = pd.merge(
    generation,
    weather,
    on=["DATE_TIME", "PLANT_ID"],
    how="inner"
)

print("Merged data:", data.shape)


# ==============================
# 4. CLEAN DATA
# ==============================

print("\nCleaning data...")

data = data.drop_duplicates()
data = data.dropna()

data["AC_POWER"] = pd.to_numeric(
    data["AC_POWER"],
    errors="coerce"
)

data["AMBIENT_TEMPERATURE"] = pd.to_numeric(
    data["AMBIENT_TEMPERATURE"],
    errors="coerce"
)

data["MODULE_TEMPERATURE"] = pd.to_numeric(
    data["MODULE_TEMPERATURE"],
    errors="coerce"
)

data["IRRADIATION"] = pd.to_numeric(
    data["IRRADIATION"],
    errors="coerce"
)

data = data.dropna()

# Remove negative target values
data = data[data["AC_POWER"] >= 0]


# ==============================
# 5. FEATURE ENGINEERING
# ==============================

print("Creating features...")

data["HOUR"] = data["DATE_TIME"].dt.hour
data["MINUTE"] = data["DATE_TIME"].dt.minute
data["DAY"] = data["DATE_TIME"].dt.day
data["MONTH"] = data["DATE_TIME"].dt.month
data["DAY_OF_WEEK"] = data["DATE_TIME"].dt.dayofweek

# Cyclic time features
data["HOUR_SIN"] = np.sin(
    2 * np.pi * data["HOUR"] / 24
)

data["HOUR_COS"] = np.cos(
    2 * np.pi * data["HOUR"] / 24
)


# ==============================
# 6. SAVE PROCESSED DATA
# ==============================

data.to_csv(
    os.path.join(PROCESSED, "renewable_energy_processed.csv"),
    index=False
)

print("Processed dataset saved.")


# ==============================
# 7. GRAPH 1
# POWER OVER TIME
# ==============================

print("\nCreating graphs...")

plt.figure(figsize=(12, 5))

plt.plot(
    data["DATE_TIME"],
    data["AC_POWER"],
    linewidth=0.7
)

plt.title("Solar AC Power Over Time")
plt.xlabel("Date")
plt.ylabel("AC Power")
plt.xticks(rotation=45)
plt.tight_layout()

plt.savefig(
    os.path.join(RESULTS, "01_power_over_time.png"),
    dpi=300
)

plt.close()


# ==============================
# 8. GRAPH 2
# IRRADIATION VS POWER
# ==============================

plt.figure(figsize=(8, 5))

plt.scatter(
    data["IRRADIATION"],
    data["AC_POWER"],
    s=5,
    alpha=0.4
)

plt.title("Irradiation vs AC Power")
plt.xlabel("Irradiation")
plt.ylabel("AC Power")
plt.tight_layout()

plt.savefig(
    os.path.join(RESULTS, "02_irradiation_vs_power.png"),
    dpi=300
)

plt.close()


# ==============================
# 9. GRAPH 3
# TEMPERATURE VS POWER
# ==============================

plt.figure(figsize=(8, 5))

plt.scatter(
    data["MODULE_TEMPERATURE"],
    data["AC_POWER"],
    s=5,
    alpha=0.4
)

plt.title("Module Temperature vs AC Power")
plt.xlabel("Module Temperature")
plt.ylabel("AC Power")
plt.tight_layout()

plt.savefig(
    os.path.join(RESULTS, "03_temperature_vs_power.png"),
    dpi=300
)

plt.close()


# ==============================
# 10. CORRELATION HEATMAP
# ==============================

corr_columns = [
    "AC_POWER",
    "AMBIENT_TEMPERATURE",
    "MODULE_TEMPERATURE",
    "IRRADIATION",
    "HOUR",
    "MINUTE",
    "DAY",
    "MONTH"
]

corr = data[corr_columns].corr()

plt.figure(figsize=(10, 7))

plt.imshow(
    corr,
    cmap="coolwarm",
    aspect="auto"
)

plt.colorbar()

plt.xticks(
    range(len(corr_columns)),
    corr_columns,
    rotation=45,
    ha="right"
)

plt.yticks(
    range(len(corr_columns)),
    corr_columns
)

plt.title("Correlation Heatmap")

plt.tight_layout()

plt.savefig(
    os.path.join(RESULTS, "04_correlation_heatmap.png"),
    dpi=300
)

plt.close()

corr.to_csv(
    os.path.join(RESULTS, "correlation_matrix.csv")
)


# ==============================
# 11. MACHINE LEARNING DATA
# ==============================

features = [
    "AMBIENT_TEMPERATURE",
    "MODULE_TEMPERATURE",
    "IRRADIATION",
    "HOUR",
    "MINUTE",
    "DAY",
    "MONTH",
    "DAY_OF_WEEK",
    "HOUR_SIN",
    "HOUR_COS"
]

X = data[features]
y = data["AC_POWER"]


# ==============================
# 12. TRAIN TEST SPLIT
# ==============================

split = int(len(data) * 0.80)

X_train = X.iloc[:split]
X_test = X.iloc[split:]

y_train = y.iloc[:split]
y_test = y.iloc[split:]

print("\nTraining samples:", len(X_train))
print("Testing samples :", len(X_test))


# ==============================
# 13. XGBOOST
# ==============================

print("\nTraining XGBoost...")

xgb = XGBRegressor(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.90,
    colsample_bytree=0.90,
    objective="reg:squarederror",
    random_state=42
)

xgb.fit(X_train, y_train)

xgb_pred = xgb.predict(X_test)


# ==============================
# 14. LIGHTGBM
# ==============================

print("Training LightGBM...")

lgb = LGBMRegressor(
    n_estimators=300,
    learning_rate=0.05,
    num_leaves=31,
    subsample=0.90,
    colsample_bytree=0.90,
    random_state=42,
    verbosity=-1
)

lgb.fit(X_train, y_train)

lgb_pred = lgb.predict(X_test)


# ==============================
# 15. EVALUATION
# ==============================

def evaluate(name, actual, predicted):

    mae = mean_absolute_error(
        actual,
        predicted
    )

    rmse = np.sqrt(
        mean_squared_error(
            actual,
            predicted
        )
    )

    r2 = r2_score(
        actual,
        predicted
    )

    print("\n" + name)

    print("MAE  :", round(mae, 4))
    print("RMSE :", round(rmse, 4))
    print("R2   :", round(r2, 4))

    return mae, rmse, r2


xgb_mae, xgb_rmse, xgb_r2 = evaluate(
    "XGBoost",
    y_test,
    xgb_pred
)

lgb_mae, lgb_rmse, lgb_r2 = evaluate(
    "LightGBM",
    y_test,
    lgb_pred
)


# ==============================
# 16. SAVE METRICS
# ==============================

metrics = pd.DataFrame({
    "Model": [
        "XGBoost",
        "LightGBM"
    ],
    "MAE": [
        xgb_mae,
        lgb_mae
    ],
    "RMSE": [
        xgb_rmse,
        lgb_rmse
    ],
    "R2": [
        xgb_r2,
        lgb_r2
    ]
})

metrics.to_csv(
    os.path.join(RESULTS, "model_metrics.csv"),
    index=False
)


# ==============================
# 17. ACTUAL VS PREDICTED
# ==============================

plt.figure(figsize=(8, 6))

plt.scatter(
    y_test,
    xgb_pred,
    s=5,
    alpha=0.4,
    label="XGBoost"
)

plt.scatter(
    y_test,
    lgb_pred,
    s=5,
    alpha=0.4,
    label="LightGBM"
)

minimum = min(
    y_test.min(),
    xgb_pred.min(),
    lgb_pred.min()
)

maximum = max(
    y_test.max(),
    xgb_pred.max(),
    lgb_pred.max()
)

plt.plot(
    [minimum, maximum],
    [minimum, maximum],
    linestyle="--"
)

plt.xlabel("Actual AC Power")
plt.ylabel("Predicted AC Power")
plt.title("Actual vs Predicted AC Power")
plt.legend()

plt.tight_layout()

plt.savefig(
    os.path.join(
        RESULTS,
        "05_actual_vs_predicted.png"
    ),
    dpi=300
)

plt.close()


# ==============================
# 18. FEATURE IMPORTANCE
# ==============================

xgb_importance = pd.DataFrame({
    "Feature": features,
    "Importance": xgb.feature_importances_
}).sort_values(
    "Importance",
    ascending=False
)

xgb_importance.to_csv(
    os.path.join(
        RESULTS,
        "06_xgboost_feature_importance.csv"
    ),
    index=False
)

plt.figure(figsize=(9, 6))

plt.barh(
    xgb_importance["Feature"],
    xgb_importance["Importance"]
)

plt.gca().invert_yaxis()

plt.title("XGBoost Feature Importance")
plt.xlabel("Importance")

plt.tight_layout()

plt.savefig(
    os.path.join(
        RESULTS,
        "06_xgboost_feature_importance.png"
    ),
    dpi=300
)

plt.close()


# ==============================
# 19. LIGHTGBM FEATURE IMPORTANCE
# ==============================

lgb_importance = pd.DataFrame({
    "Feature": features,
    "Importance": lgb.feature_importances_
}).sort_values(
    "Importance",
    ascending=False
)

lgb_importance.to_csv(
    os.path.join(
        RESULTS,
        "07_lightgbm_feature_importance.csv"
    ),
    index=False
)

plt.figure(figsize=(9, 6))

plt.barh(
    lgb_importance["Feature"],
    lgb_importance["Importance"]
)

plt.gca().invert_yaxis()

plt.title("LightGBM Feature Importance")
plt.xlabel("Importance")

plt.tight_layout()

plt.savefig(
    os.path.join(
        RESULTS,
        "07_lightgbm_feature_importance.png"
    ),
    dpi=300
)

plt.close()


# ==============================
# 20. MODEL COMPARISON
# ==============================

plt.figure(figsize=(7, 5))

plt.bar(
    ["XGBoost", "LightGBM"],
    [xgb_mae, lgb_mae]
)

plt.ylabel("MAE")
plt.title("MAE Comparison")

plt.tight_layout()

plt.savefig(
    os.path.join(
        RESULTS,
        "comparison_mae.png"
    ),
    dpi=300
)

plt.close()


plt.figure(figsize=(7, 5))

plt.bar(
    ["XGBoost", "LightGBM"],
    [xgb_rmse, lgb_rmse]
)

plt.ylabel("RMSE")
plt.title("RMSE Comparison")

plt.tight_layout()

plt.savefig(
    os.path.join(
        RESULTS,
        "comparison_rmse.png"
    ),
    dpi=300
)

plt.close()


plt.figure(figsize=(7, 5))

plt.bar(
    ["XGBoost", "LightGBM"],
    [xgb_r2, lgb_r2]
)

plt.ylabel("R² Score")
plt.title("R² Score Comparison")

plt.tight_layout()

plt.savefig(
    os.path.join(
        RESULTS,
        "comparison_r2.png"
    ),
    dpi=300
)

plt.close()


# ==============================
# 21. SAVE PREDICTIONS
# ==============================

predictions = pd.DataFrame({
    "Actual_AC_POWER": y_test.values,
    "XGBoost_Prediction": xgb_pred,
    "LightGBM_Prediction": lgb_pred
})

predictions.to_csv(
    os.path.join(
        RESULTS,
        "predictions.csv"
    ),
    index=False
)


# ==============================
# 22. SAVE MODELS
# ==============================

joblib.dump(
    xgb,
    os.path.join(
        MODELS,
        "xgboost_model.pkl"
    )
)

joblib.dump(
    lgb,
    os.path.join(
        MODELS,
        "lightgbm_model.pkl"
    )
)


# ==============================
# 23. FINAL MESSAGE
# ==============================

print("\n===================================")
print("PROJECT COMPLETED SUCCESSFULLY")
print("===================================")

print("\nGraphs saved in:")
print("results/")

print("\nModels saved in:")
print("models/")

print("\nProcessed dataset saved in:")
print("dataset/processed/")